﻿using DotNetty.Transport.Channels;
using Protocol.MemoryPack;

namespace NettyClient.InboundHandler;

public class MemoryPackMessageHandler : SimpleChannelInboundHandler<IPacket>
{
    protected override void ChannelRead0(IChannelHandlerContext ctx, IPacket msg)
    {
        _ = HandleMessageAsync(ctx, msg).ConfigureAwait(false);
    }
    
    private static async Task HandleMessageAsync(IChannelHandlerContext context, IPacket message)
    {
        if (message is PongPacket packet)
        {
            Console.WriteLine($"{context.Channel.Id}: {packet.Data} {packet.Time}");    
        }
        
        await Task.Delay(10);
        await context.WriteAndFlushAsync(new PingPacket
        {
            Data = Random.Shared.Next(),
            Time = DateTime.UtcNow
        });
    }
    
    public override void ExceptionCaught(IChannelHandlerContext context, Exception exception)
    {
        Console.WriteLine(exception);
        context.CloseAsync();
    }
}