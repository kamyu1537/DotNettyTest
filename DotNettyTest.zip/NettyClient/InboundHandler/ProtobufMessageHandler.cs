﻿using DotNetty.Transport.Channels;
using Google.Protobuf;
using NetProtocol;

namespace NettyClient.InboundHandler;

public class ProtobufMessageHandler : SimpleChannelInboundHandler<IMessage>
{
    protected override void ChannelRead0(IChannelHandlerContext context, IMessage message)
    {
        _ = HandleMessageAsync(context, message).ConfigureAwait(false);
    }

    private static async Task HandleMessageAsync(IChannelHandlerContext context, IMessage message)
    {
        Console.WriteLine($"{context.Channel.Id}: {message}");
        
        await Task.Delay(10);
        await context.WriteAndFlushAsync(new Ping
        {
            Data = Random.Shared.Next(),
            Time = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()
        });
    }

    public override void ExceptionCaught(IChannelHandlerContext context, Exception exception)
    {
        Console.WriteLine("[MessageHandler] ExceptionCaught: " + exception);
        base.ExceptionCaught(context, exception);
    }
}