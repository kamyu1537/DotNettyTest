﻿using DotNetty.Transport.Channels;
using NetProtocol;

namespace NettyClient.Adapter;

public class SendProtobufPingAdapter : ChannelHandlerAdapter
{
    public override void ChannelActive(IChannelHandlerContext context)
    {
        base.ChannelActive(context);

        context.WriteAndFlushAsync(new Ping
        {
            Data = Random.Shared.Next(),
            Time = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()
        });
        Console.WriteLine($"Send: {context.Channel.Id}");
    }
}