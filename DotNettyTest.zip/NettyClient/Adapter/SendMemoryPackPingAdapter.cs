﻿using DotNetty.Transport.Channels;
using Protocol.MemoryPack;

namespace NettyClient.Adapter;

public class SendMemoryPackPingAdapter : ChannelHandlerAdapter
{
    public override void ChannelActive(IChannelHandlerContext context)
    {
        base.ChannelActive(context);

        context.WriteAndFlushAsync(new PingPacket
        {
            Data = Random.Shared.Next(),
            Time = DateTime.UtcNow
        });
        
        Console.WriteLine($"Send: {context.Channel.Id}");
    }
}