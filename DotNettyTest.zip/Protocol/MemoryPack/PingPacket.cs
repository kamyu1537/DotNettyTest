﻿using MemoryPack;

namespace Protocol.MemoryPack;

[MemoryPackable]
public partial class PingPacket : IPacket
{
    public int Data { get; set; }
    public DateTime Time { get; set; }
}