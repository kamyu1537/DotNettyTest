﻿using MemoryPack;

namespace Protocol.MemoryPack;

[MemoryPackable]
public partial class PongPacket : IPacket
{
    public int Data { get; set; }
    public DateTime Time { get; set; }
}